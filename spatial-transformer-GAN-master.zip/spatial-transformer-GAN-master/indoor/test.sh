python3 eval_STGAN.py --loadGP=0/test_warp4_it40000 --warpN=4
