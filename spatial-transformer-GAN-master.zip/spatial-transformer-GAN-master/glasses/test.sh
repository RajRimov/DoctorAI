python3 eval_STGAN.py --loadGP=0/test0_warp5_it50000 --warpN=5 --loadImage=dataset/example_test.png
